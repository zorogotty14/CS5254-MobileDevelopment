package edu.vt.cs5254.multiquiz

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import edu.vt.cs5254.multiquiz.SummaryActivity.Companion.newIntent
import edu.vt.cs5254.multiquiz.databinding.ActivitySummaryBinding

private const val EXTRA_CA = "edu.vt.cs5254.multiquiz.correct_answers"
private const val EXTRA_HU = "edu.vt.cs5254.multiquiz.hints_used"
const val EXTRA_RESET_ALL = "edu.vt.cs5254.multiquiz.reset_all"

class SummaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySummaryBinding
    private val resultVM: ResultViewModel by viewModels()
    private var correctAnswers: Int = 0
    private var hintsUsed: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySummaryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.resetAllButton.setOnClickListener {
            resultVM.resetClicked()
            updateView()
        }
        updateView()
    }

    override fun onBackPressed() {
        val intent = Intent(this, SummaryActivity::class.java)
        intent.putExtra(EXTRA_RESET_ALL, resultVM.reset)
        intent.putExtra(EXTRA_CA, correctAnswers)
        intent.putExtra(EXTRA_HU, hintsUsed)
        setResult(RESULT_OK, intent)
        finish()
    }

    private fun updateView() {
        val correctAnswers = if (resultVM.reset) 0 else intent.getIntExtra(EXTRA_CA, 0)
        val hintsUsed = if (resultVM.reset) 0 else intent.getIntExtra(EXTRA_HU, 0)

        binding.correctAnswersCount.text = correctAnswers.toString()
        binding.hintsUsedCount.text = hintsUsed.toString()

        binding.resetAllButton.isEnabled = !resultVM.reset
        if (resultVM.reset) {
            resultVM.resetClicked()
        }
    }

    companion object {
        fun newIntent(context: Context, correctAnswers: Int, hintsUsed: Int): Intent {
            return Intent(context, SummaryActivity::class.java).apply {
                putExtra(EXTRA_CA, correctAnswers)
                putExtra(EXTRA_HU, hintsUsed)
            }
        }
    }

}


