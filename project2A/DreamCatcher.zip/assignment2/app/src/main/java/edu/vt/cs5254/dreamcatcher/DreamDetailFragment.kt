package edu.vt.cs5254.dreamcatcher

import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import edu.vt.cs5254.dreamcatcher.databinding.FragmentDreamDetailBinding

class DreamDetailFragment : Fragment() {
    // Name: gautham gali
   // PID: 906577777
    private var _binding: FragmentDreamDetailBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "FragmentDreamDetailBinding is null!!!!!!!!"
        }
    private val dreamCatcherDetailsVM: DreamDetailViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDreamDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.deferredCheckbox.setOnClickListener {
            if (!binding.deferredCheckbox.isChecked) {
                dreamCatcherDetailsVM.removeDefItem()
            } else {
                dreamCatcherDetailsVM.addDefItem()
            }
            updateView()
        }

        binding.fulfilledCheckbox.setOnClickListener {
            if (!binding.fulfilledCheckbox.isChecked) {
                dreamCatcherDetailsVM.removeFulfillItem()
            } else {
                dreamCatcherDetailsVM.addFulfillItem()
            }
            updateView()
        }

        binding.titleText.doOnTextChanged { text, _, _, _ ->
            dreamCatcherDetailsVM.dream = dreamCatcherDetailsVM.dream.copy(title = text.toString())
                .apply { entries = dreamCatcherDetailsVM.dream.entries }
        }
        updateView()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun updateView() {
        val buttonList = listOf(
            binding.entry0Button,
            binding.entry1Button,
            binding.entry2Button,
            binding.entry3Button,
            binding.entry4Button
        )

        buttonList.forEach {
            it.visibility = View.GONE
        }

        buttonList.zip(dreamCatcherDetailsVM.dream.entries) { button, entry ->
            button.displayEntry(entry)
        }

        val dateFormat =
            DateFormat.format("yyyy-MM-dd 'at' hh:mm:ss a", dreamCatcherDetailsVM.dream.lastUpdated)
        binding.lastUpdatedText.text = getString(R.string.last_updated_text, dateFormat)

        if (dreamCatcherDetailsVM.dream.title != binding.titleText.toString()) {
            binding.titleText.setText(dreamCatcherDetailsVM.dream.title)
        }

        binding.deferredCheckbox.isChecked = dreamCatcherDetailsVM.dream.isDeferred
        binding.fulfilledCheckbox.isChecked = dreamCatcherDetailsVM.dream.isFulfilled
        binding.deferredCheckbox.isEnabled = !dreamCatcherDetailsVM.dream.isFulfilled
        binding.fulfilledCheckbox.isEnabled = !dreamCatcherDetailsVM.dream.isDeferred
    }

    private fun Button.displayEntry(entry: DreamEntry) {
        visibility = View.VISIBLE
        text = entry.kind.toString()
        when (entry.kind) {
            DreamEntryKind.CONCEIVED -> {
                setBackgroundWithContrastingText("#77D02F")
            }
            DreamEntryKind.FULFILLED -> {
                setBackgroundWithContrastingText("#3DC270")
            }
            DreamEntryKind.DEFERRED -> {
                setBackgroundWithContrastingText("#D02F77")
            }
            DreamEntryKind.REFLECTION -> {
                setBackgroundWithContrastingText("#2F77D0")
                isAllCaps = false
                text = entry.text
            }
        }
    }
}