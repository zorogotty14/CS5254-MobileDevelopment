package edu.vt.cs5254.dreamcatcher

import androidx.lifecycle.ViewModel

class DreamDetailViewModel : ViewModel() {
    // Name: gautham gali
    // PID: 906577777
    var dream: Dream

    init {
        dream = Dream(title = "My First Dream")
        dream.entries += listOf(
            DreamEntry(
                kind = DreamEntryKind.REFLECTION,
                text = "Reflection One",
                dreamId = dream.id
            ),
            DreamEntry(
                kind = DreamEntryKind.REFLECTION,
                text = "Reflection Two",
                dreamId = dream.id
            ),
            DreamEntry(
                kind = DreamEntryKind.DEFERRED,
                dreamId = dream.id
            )
        )
    }
    fun removeDefItem() {
        dream.entries = dream.entries.dropLast(1)
    }

    fun addDefItem() {
        dream.entries += listOf(DreamEntry(kind = DreamEntryKind.DEFERRED, dreamId = dream.id))
    }

    fun removeFulfillItem() {
        dream.entries = dream.entries.take(3)
    }

    fun addFulfillItem() {
        dream.entries += listOf(DreamEntry(kind = DreamEntryKind.FULFILLED, dreamId = dream.id))
    }
}