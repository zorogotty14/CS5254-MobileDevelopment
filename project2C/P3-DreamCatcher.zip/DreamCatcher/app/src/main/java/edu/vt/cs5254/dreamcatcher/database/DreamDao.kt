package edu.vt.cs5254.dreamcatcher.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import edu.vt.cs5254.dreamcatcher.Dream
import edu.vt.cs5254.dreamcatcher.DreamEntry
import java.util.UUID
import kotlinx.coroutines.flow.Flow

@Dao
interface DreamDao {
    @Query("SELECT * FROM dream d JOIN dream_entry e ON e.dreamId = d.id ORDER BY d.lastUpdated DESC")
    fun getDreams(): Flow<Map<Dream, List<DreamEntry>>>

    @Query("SELECT * FROM dream WHERE id=(:id)")
    suspend fun internalGetDream(id: UUID): Dream

    @Query("SELECT * FROM dream_entry WHERE dreamId = (:dreamId)")
    suspend fun internalGetEntriesForDream(dreamId: UUID): List<DreamEntry>

    @Transaction
    suspend fun getDreamAndEntries(id: UUID): Dream {
        return internalGetDream(id).apply { entries = internalGetEntriesForDream(id) }
    }

    @Update
    suspend fun internalUpdateDream(dream: Dream)

    @Query("DELETE FROM dream_entry where dreamId = (:id)")
    suspend fun internalDeleteEntriesFromDream(id: UUID)

    @Insert
    suspend fun internalInsertDreamEntry(dreamEntry: DreamEntry)

    @Transaction
    suspend fun updateDreamAndEntries(dream: Dream) {
        internalDeleteEntriesFromDream(dream.id)
        dream.entries.forEach { internalInsertDreamEntry(it) }
        internalUpdateDream(dream)
    }
    @Insert
    suspend fun internalInsertDream(dream: Dream)

    @Transaction
    suspend fun  internalInsertDreamAndEntries(dream: Dream) {
        internalInsertDream(dream)
        dream.entries.forEach { internalInsertDreamEntry(it) }
    }

    @Delete
    suspend fun internalDeleteDream(dream: Dream)

    @Transaction
    suspend fun interalDeleteDreamAndEntries(dream: Dream) {
        internalDeleteEntriesFromDream(dream.id)
        internalDeleteDream(dream)
    }



}