package edu.vt.cs5254.dreamcatcher

import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import edu.vt.cs5254.dreamcatcher.databinding.FragmentDreamDetailBinding
import kotlinx.coroutines.launch

class DreamDetailFragment : Fragment() {
    // Name: gautham gali
   // PID: 906577777
    private val args: DreamDetailFragmentArgs by navArgs()
    private var _binding: FragmentDreamDetailBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "FragmentDreamDetailBinding is null!!!!!!!!"
        }
    private val dreamCatcherDetailsVM: DreamDetailViewModel by viewModels(){
        DreamDetailViewModelFactory(args.dreamId)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDreamDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.deferredCheckbox.setOnClickListener {
            dreamCatcherDetailsVM.updateDream { oldDream ->
                if (!binding.deferredCheckbox.isChecked) {
                    var did = oldDream.entries[0].id
                    var ddid = oldDream.entries[0].dreamId
                    var dtxt = oldDream.entries[0].text
                    oldDream.entries.forEach() {
                        if(DreamEntryKind.DEFERRED == it.kind) {
                            did = it.id
                            ddid = it.dreamId
                            dtxt = it.text
                        }
                    }
                    oldDream.copy().apply {
                        entries = oldDream.entries - DreamEntry(
                            id = did,
                            kind = DreamEntryKind.DEFERRED,
                            dreamId = ddid,
                            text = dtxt
                        )
                    }
                } else {
                    oldDream.copy().apply {
                        entries = oldDream.entries + DreamEntry(
                            kind = DreamEntryKind.DEFERRED,
                            dreamId = oldDream.id
                        )
                    }
                }
            }
        }

        binding.fulfilledCheckbox.setOnClickListener {
            dreamCatcherDetailsVM.updateDream { oldDream ->
                if(oldDream.isFulfilled) {
                    var did = oldDream.entries[0].id
                    var ddid = oldDream.entries[0].dreamId
                    var dtxt = oldDream.entries[0].text
                    oldDream.entries.forEach() {
                        if(DreamEntryKind.FULFILLED == it.kind) {
                            did = it.id
                            ddid = it.dreamId
                            dtxt = it.text
                        }
                    }
                    oldDream.copy().apply {
                        entries = oldDream.entries - DreamEntry(
                            id = did,
                            kind = DreamEntryKind.FULFILLED,
                            dreamId = ddid,
                            text = dtxt
                        )
                    }
                } else {
                    oldDream.copy().apply {
                        entries = oldDream.entries + DreamEntry(
                            kind = DreamEntryKind.FULFILLED,
                            dreamId = oldDream.id
                        )
                    }
                }
            }
        }


        binding.titleText.doOnTextChanged { text, _, _, _ ->
            dreamCatcherDetailsVM.updateDream { oldDream ->
                oldDream.copy(title = text.toString())
                    .apply { entries = oldDream.entries }
            }

        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                dreamCatcherDetailsVM.dream.collect { dream ->
                    dream?.let { updateView(it) }
                }
            }
        }

        setFragmentResultListener(
            ReflectionDialogFragment.REQUEST_KEY) { requestKey, bundle ->
            val entryText = bundle.getString(ReflectionDialogFragment.BUNDLE_KEY) ?: ""
            (dreamCatcherDetailsVM.updateDream { oldDream ->
                oldDream.copy().apply {
                    entries = oldDream.entries + DreamEntry(
                        kind = DreamEntryKind.REFLECTION,
                        text = entryText,
                        dreamId = oldDream.id
                    )
                }
            })
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun updateView(dream: Dream) {
        val buttonList = listOf(
            binding.entry0Button,
            binding.entry1Button,
            binding.entry2Button,
            binding.entry3Button,
            binding.entry4Button
        )

        buttonList.forEach {
            it.visibility = View.GONE
        }

        buttonList.zip(dream.entries) { button, entry ->
            button.displayEntry(entry)
        }

        val formattedDate =
            DateFormat.format("yyyy-MM-dd 'at' hh:mm:ss a", dream.lastUpdated)
        binding.lastUpdatedText.text = getString(R.string.last_updated_text, formattedDate)

        if (dream.title != binding.titleText.toString()) {
            binding.titleText.setText(dream.title)
        }

        if(!dream.isFulfilled) {
            binding.addReflectionButton.show()
        }
        else {
            binding.addReflectionButton.hide()
        }

        binding.addReflectionButton.setOnClickListener {
            findNavController().navigate(
                DreamDetailFragmentDirections.addReflection()
            )
        }

        binding.deferredCheckbox.isChecked = dream.isDeferred
        binding.fulfilledCheckbox.isChecked = dream.isFulfilled
        binding.deferredCheckbox.isEnabled = !dream.isFulfilled
        binding.fulfilledCheckbox.isEnabled = !dream.isDeferred
    }

    private fun Button.displayEntry(entry: DreamEntry) {
        visibility = View.VISIBLE
        text = entry.kind.toString()
        when (entry.kind) {
            DreamEntryKind.CONCEIVED -> {
                setBackgroundWithContrastingText("#77D02F")
            }
            DreamEntryKind.FULFILLED -> {
                setBackgroundWithContrastingText("#3DC270")
            }
            DreamEntryKind.DEFERRED -> {
                setBackgroundWithContrastingText("#D02F77")
            }
            DreamEntryKind.REFLECTION -> {
                setBackgroundWithContrastingText("#2F77D0")
                isAllCaps = false
                text = entry.text
            }
        }
    }
}