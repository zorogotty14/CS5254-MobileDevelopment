package edu.vt.cs5254.dreamcatcher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import edu.vt.cs5254.dreamcatcher.databinding.ListItemDreamBinding
import java.util.UUID

class DreamHolder(private val binding: ListItemDreamBinding): RecyclerView.ViewHolder(binding.root) {
// Name: gautham gali
// PID: 906577777
    fun bind(dream: Dream, onDreamClicked: (UUID) -> Unit ) {
        binding.root.setOnClickListener {
            onDreamClicked(dream.id)
        }
        val reflectionCount = dream.entries.count { it.kind == DreamEntryKind.REFLECTION }
        val reflectionString = binding.root.context.getString(R.string.reflection_count_text,reflectionCount )
        binding.listItemTitle.text = dream.title
        binding.listItemReflectionCount.text = reflectionString

        if(dream.isFulfilled) {
            binding.listItemImage.setImageResource(R.drawable.ic_dream_fulfilled)
            binding.listItemImage.visibility = View.VISIBLE
        }
        else if(dream.isDeferred) {
            binding.listItemImage.setImageResource(R.drawable.ic_dream_deferred)
            binding.listItemImage.visibility = View.VISIBLE
        }
        else {
            binding.listItemImage.visibility = View.GONE
        }
    }
}

class DreamAdapter(
    private val dreams: List<Dream>,
    private val onDreamClicked: (UUID) -> Unit
    ) : RecyclerView.Adapter<DreamHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DreamHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ListItemDreamBinding.inflate(inflater, parent, false)
        return DreamHolder(binding)
    }

    override fun onBindViewHolder(holder: DreamHolder, position: Int) {
        holder.bind(dreams[position], onDreamClicked)
    }

    override fun getItemCount(): Int {
        return dreams.size
    }
}
